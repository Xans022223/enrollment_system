<section class="dashboard">
  <h2>Dashboard</h2>
  <p>Welcome back! Use the navigation to manage your tasks.</p>
</section>