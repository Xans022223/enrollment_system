<section class="error error-404">
  <h2>404 - Not Found</h2>
  <p>The page you are looking for could not be found.</p>
  <p><a href="index.php">Go to Home</a></p>
</section>